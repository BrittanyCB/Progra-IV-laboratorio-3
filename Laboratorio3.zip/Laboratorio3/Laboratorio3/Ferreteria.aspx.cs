﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Capa_Datos;
using Capa_Datos.Tablas;

namespace Laboratorio3
{
    public partial class Ferreteria : System.Web.UI.Page
    {
        ManejoBD objBD;
        List<CatDisponible> listadoDisp;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                cargarCmbDisp();
            }

        }
        void cargarCmbDisp()
        {
            objBD = new ManejoBD();
            listadoDisp = objBD.listadoDisp();

            cmbDisponible.DataSource = listadoDisp;
            cmbDisponible.DataTextField = "Descripcion";
            cmbDisponible.DataValueField = "IDDisp";
            cmbDisponible.DataBind();


        }

        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            objBD = new ManejoBD();
            Capa_Datos.Tablas.Herramientas objHerramienta = new Capa_Datos.Tablas.Herramientas();
            objHerramienta.IDHerramienta =Convert.ToInt32(txtidHerramienta.Text);
            objHerramienta.NombreHerramienta = txtnomHerramienta.Text;
            objHerramienta.MarcaHerramienta = txtmarcaHerramienta.Text;
            objHerramienta.PrecioHerramienta =Convert.ToInt32(txtprecioHerramienta.Text);

            bool resultado = objBD.registrarHerramienta(objHerramienta);


            if (resultado)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "scr1", "Swal.fire('Registro de la herramienta con exito')", true);
                return;
            }

            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "scr1", "alert('No se logro registrar la herramienta')", true);

        }

        protected void btnActualizar_Click(object sender, EventArgs e)
        {
            objBD = new ManejoBD();
            Capa_Datos.Tablas.Herramientas objHerramienta = new Capa_Datos.Tablas.Herramientas();
            objHerramienta.IDHerramienta = Convert.ToInt32(txtidHerramienta.Text);
            objHerramienta.NombreHerramienta = txtnomHerramienta.Text;
            objHerramienta.MarcaHerramienta = txtmarcaHerramienta.Text;
            objHerramienta.PrecioHerramienta = Convert.ToInt32(txtprecioHerramienta.Text);

            bool resultado = objBD.actualizarHerramienta(objHerramienta);


            if (resultado)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "scr1", "Swal.fire('Actualizacion de la herramienta con exito')", true);
                return;
            }

            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "scr1", "alert('No se logro actualizar la herramienta')", true);

        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            objBD = new ManejoBD();
            Capa_Datos.Tablas.Herramientas objHerramienta = new Capa_Datos.Tablas.Herramientas();
            objHerramienta.IDHerramienta = Convert.ToInt32(txtidHerramienta.Text);
            objHerramienta.NombreHerramienta = txtnomHerramienta.Text;
            objHerramienta.MarcaHerramienta = txtmarcaHerramienta.Text;
            objHerramienta.PrecioHerramienta = Convert.ToInt32(txtprecioHerramienta.Text);

            bool resultado = objBD.eliminarHerramienta(objHerramienta);


            if (resultado)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "scr1", "Swal.fire('Eliminacion de la herramienta con exito')", true);
                return;
            }

            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "scr1", "alert('No se logro eliminar la herramienta')", true);

        }
    }
}