﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capa_Datos.Tablas
{
    public class CatDisponible
    {
        public int IDDisp { get; set; }

        public string Descripcion { get; set; }
    }
}
