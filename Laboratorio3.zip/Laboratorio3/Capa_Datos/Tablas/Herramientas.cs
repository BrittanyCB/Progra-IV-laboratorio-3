﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capa_Datos.Tablas
{
     public class Herramientas
    {
        public int IDHerramienta { get; set;}
        public string NombreHerramienta { get; set;}
        public string MarcaHerramienta { get; set; }
        public int PrecioHerramienta { get; set; }
    }
}
